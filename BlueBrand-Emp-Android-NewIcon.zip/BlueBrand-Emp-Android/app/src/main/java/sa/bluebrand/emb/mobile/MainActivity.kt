package sa.bluebrand.emb.mobile

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.firebase.messaging.FirebaseMessaging
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var chooserCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private val home = "https://bluebrand-emp.web.app"

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val cb = chooserCallback ?: return@registerForActivityResult
        val data = result.data
        val resultUris = when {
            result.resultCode != RESULT_OK -> null
            data?.clipData != null -> Array(data.clipData!!.itemCount) { data.clipData!!.getItemAt(it).uri }
            data?.data != null -> arrayOf(data.data!!)
            cameraUri != null -> arrayOf(cameraUri!!)
            else -> null
        }
        cb.onReceiveValue(resultUris)
        chooserCallback = null
        cameraUri = null
    }

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) web.reload()
    }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(false)
        web = WebView(this)
        setContentView(web)

        createNotificationChannel()
        askNotificationPermission()

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            userAgentString = "$userAgentString BlueBrandEmpAndroid/1.0"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "bluebrand" && u.host == "print") { printPage(); return true }
                if (u.scheme == "bluebrand-download") { return true }
                return if (u.scheme == "http" || u.scheme == "https") false else {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) { }
                    true
                }
            }
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                injectNativeHooks()
                publishFcmToken()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        cameraPermission.launch(Manifest.permission.CAMERA)
                    } else request.grant(request.resources)
                } else request.grant(request.resources)
            }
            override fun onShowFileChooser(webView: WebView, filePathCallback: ValueCallback<Array<Uri>>, fileChooserParams: FileChooserParams): Boolean {
                chooserCallback?.onReceiveValue(null)
                chooserCallback = filePathCallback
                val content = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE); addCategory(Intent.CATEGORY_OPENABLE) }
                val camera = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                val dir = File(cacheDir, "camera").apply { mkdirs() }
                val photo = File(dir, "capture_${System.currentTimeMillis()}.jpg")
                cameraUri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", photo)
                camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val chooser = Intent.createChooser(content, "اختيار ملف").apply { putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(camera)) }
                filePicker.launch(chooser)
                return true
            }
        }

        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            } catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })

        val initial = intent.getStringExtra("notification_url") ?: home
        web.loadUrl(initial)
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            getSharedPreferences("bluebrand", MODE_PRIVATE).edit().putString("fcm_token", token).apply()
            publishFcmToken()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra("notification_url")?.let { web.loadUrl(it) }
    }

    private fun injectNativeHooks() {
        val js = """
            (function(){
              if(window.__bluebrandNativeInstalled)return; window.__bluebrandNativeInstalled=true;
              window.print=function(){ location.href='bluebrand://print'; };
              document.addEventListener('click',function(e){
                var a=e.target.closest&&e.target.closest('a[download]');
                if(a && a.href && a.href.indexOf('blob:')===0){
                  e.preventDefault(); fetch(a.href).then(r=>r.blob()).then(b=>{var fr=new FileReader();fr.onloadend=()=>{location.href='bluebrand-download://'+encodeURIComponent(a.download||'download')+'?data='+encodeURIComponent(fr.result)};fr.readAsDataURL(b);});
                }
              },true);
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    private fun publishFcmToken() {
        if (!::web.isInitialized) return
        val token = getSharedPreferences("bluebrand", MODE_PRIVATE).getString("fcm_token", null) ?: return
        val safe = token.replace("\\", "\\\\").replace("'", "\\'")
        web.post { web.evaluateJavascript("window.dispatchEvent(new CustomEvent('bluebrand-fcm-token',{detail:'$safe'})); try{localStorage.setItem('bluebrand_fcm_token','$safe')}catch(e){}", null) }
    }

    private fun printPage() {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print("BlueBrand Emp", web.createPrintDocumentAdapter("BlueBrand Emp"), PrintAttributes.Builder().build())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            (getSystemService(NotificationManager::class.java)).createNotificationChannel(NotificationChannel("bluebrand_emp_general", "BlueBrand Emp", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}
