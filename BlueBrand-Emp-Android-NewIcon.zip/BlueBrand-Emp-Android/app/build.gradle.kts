plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}

android {
    namespace = "sa.bluebrand.emb.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "sa.bluebrand.emb.mobile"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-messaging")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity:1.10.0")
    implementation("androidx.core:core:1.15.0")
}
